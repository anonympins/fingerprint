<?php

declare(strict_types=1);

namespace Anonympins\Fingerprint;

/**
 * Représente le contexte d'une requête HTTP, fournissant un accès unifié
 * aux informations nécessaires pour l'analyse de l'empreinte.
 * Cette classe est conçue pour être créée à partir d'un objet de requête
 * standard (ex: PSR-7, Symfony, Laravel).
 */
class RequestContext
{
    public string $clientIp = '';
    public string $path = '';
    /** @var array<string, string> */
    public array $headers = [];
    /** @var array<string, mixed> */
    public array $query = [];
    /** @var array<string, mixed>|object|null */
    public $body = null;
    /** @var array<string, string> */
    public array $cookies = [];
    public ?string $httpVersion = null;
    public int $requestTimestamp = 0;
    public ?string $tlsSessionId = null;
    public bool $isHttps = false;

    /** @var ?array{type: string, name: string} */
    public ?array $graphqlOperation = null;

    /** @var ?array<string, mixed> */
    public ?array $newCookieForResponse = null;

    /** @var ?array<string, mixed> */
    public ?array $resolvedIdentity = null;

    public ?float $preCalculatedScore = null;
    /** @var ?array<string, float> */
    public ?array $preCalculatedVector = null;

    // Propriétés spécifiques qui peuvent être fournies par un proxy inverse
    public ?string $ja3 = null;
    public ?string $ja4 = null;
    public ?string $ja4s = null;
    public ?string $ja4h = null;
    public ?string $http2Fingerprint = null;
    public ?string $quicFingerprint = null;
    public ?string $tcpFingerprint = null;
    public ?string $zkpY = null; // NOUVEAU: Clé publique ZKP du client

    /**
     * @param string $clientIp
     * @param string $path
     * @param array<string, string> $headers
     * @param array<string, mixed> $query
     * @param array<string, mixed>|object|null $body
     * @param array<string, string> $cookies
     * @param string|null $httpVersion
     * @param int|null $requestTimestamp
     */
    public function __construct(
        string $clientIp,
        string $path,
        array $headers,
        array $query,
        $body,
        array $cookies,
        ?string $httpVersion,
        ?int $requestTimestamp = null,
        ?bool $isHttps = null
    ) {
        $this->clientIp = $clientIp;
        $this->path = $path;
        // Normaliser les en-têtes en minuscules pour un accès cohérent
        $this->headers = array_change_key_case($headers, CASE_LOWER);
        $this->query = $query;
        $this->body = $body;
        $this->cookies = $cookies;
        $this->httpVersion = $httpVersion;
        $this->requestTimestamp = $requestTimestamp ?? (int)(microtime(true) * 1000);
        $this->isHttps = $isHttps ?? (
            (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ||
            (isset($_SERVER['SERVER_PORT']) && (int)$_SERVER['SERVER_PORT'] === 443) ||
            ($this->getHeader('x-forwarded-proto') === 'https')
        );

        // Extraire les empreintes TLS/HTTP2/TCP si elles sont fournies par les en-têtes
        $this->ja3 = $this->headers['x-ja3-hash'] ?? null;
        $this->ja4 = $this->headers['x-ja4-hash'] ?? null;
        $this->ja4s = $this->headers['x-ja4s-hash'] ?? null;
        $this->ja4h = $this->headers['x-ja4h-hash'] ?? null;
        $this->http2Fingerprint = $this->headers['x-http2-fingerprint'] ?? null;
        $this->tcpFingerprint = $this->headers['x-tcp-fingerprint'] ?? null;
        $this->quicFingerprint = $this->headers['x-quic-fp'] ?? null;
        $this->zkpY = isset($this->headers['x-zkp-proof']) ? explode(':', $this->headers['x-zkp-proof'])[0] : null;
        $this->tlsSessionId = $this->headers['x-tls-session-id'] ?? $this->headers['x-ssl-session-id'] ?? null;
    }
    /**
     * Récupère la valeur d'un en-tête HTTP de manière insensible à la casse.
     *
     * @param string $name Le nom de l'en-tête.
     * @return string|null La valeur de l'en-tête ou null si non trouvé.
     */

    public function getHeader(string $name): ?string
    {
        return $this->headers[strtolower($name)] ?? null;
    }
}
<?php

declare(strict_types=1);

namespace Anonympins\Fingerprint\Challenge;

use Anonympins\Fingerprint\Store\StoreManager;
use Anonympins\Fingerprint\FingerprintBuilder;
use Anonympins\Fingerprint\Utils\BigInt;
use Anonympins\Fingerprint\Utils\RequestUtils;
 use Anonympins\Fingerprint\Utils\Env;

/**
 * Classe utilitaire pour la génération et la vérification des challenges Proof-of-Work.
 */
class ChallengeUtils
{
    /** @var array<string, float> Cache local des floats convertis pour éviter les appels système pack/unpack */
    private static array $froundCache = [];

    private static function fround(float $value): float
    {
        $key = (string)$value;
        return self::$froundCache[$key] ?? (self::$froundCache[$key] = unpack('f', pack('f', $value))[1]);
    }

    public static function hashSeedToFloat(string $seed): float
    {
        $hash = 0;
        for ($i = 0; $i < strlen($seed); $i++) {
            $hash = (($hash << 5) - $hash + ord($seed[$i])) & 0xffffffff;
            if ($hash & 0x80000000) {
                $hash = $hash - 0x100000000;
            }
        }
        return abs($hash % 1000000) / 1000000;
    }

    public static function deriveSampleIndices(string $clientIp, string $secret): array
    {
        $timeWindow = (int)floor(time() / (60 * 5));
        $message = "{$clientIp}:{$timeWindow}";
        $hmacHex = hash_hmac('sha256', $message, $secret ?: 'gpu-pow-salt');
        $hmacBytes = array_values(unpack('C*', hex2bin($hmacHex)));

        $indices = [];
        for ($i = 0; $i < 4; $i++) {
            $offset = ($i * 2) % count($hmacBytes);
            $value = ($hmacBytes[$offset] << 8) | $hmacBytes[($offset + 1) % count($hmacBytes)];
            $idx = $value % 64;
            while (in_array($idx, $indices, true)) {
                $idx = ($idx + 1) % 64;
            }
            $indices[] = $idx;
        }
        return $indices;
    }

    public static function verifyGpuPow(string $seed, int $iterations, string $solution, string $clientIp = '127.0.0.1', string $secret = 'gpu-pow-salt'): bool
    {
        $values = explode(',', $solution);
        if (count($values) !== 64) {
            return false;
        }
        $sampleIndices = self::deriveSampleIndices($clientIp, $secret);
        $numericSeed = self::hashSeedToFloat($seed);
        $r = 3.9999;
        foreach ($sampleIndices as $idx) {
            if ($idx < 0 || $idx >= 64) {
                return false;
            }
            $x = self::fround(fmod($numericSeed + $idx * 0.015, 1.0));
            $rFloat = self::fround($r);
            for ($i = 0; $i < $iterations; $i++) {
                $x = self::fround($rFloat * $x * self::fround(1.0 - $x));
            }
            $clientVal = (float)$values[$idx];
            if (abs($clientVal - $x) > 1e-4) {
                return false;
            }
        }
        return true;
    }

    private const TRAP_URL_TEMPLATES = [
        '/includes/config-{RANDOM}.php',
        '/.env.{RANDOM}',
        '/backups/db_backup_{RANDOM}.sql.gz',
        '/api/v1/internal/status?trace={RANDOM}',
        '/_private/deploy_key_{RANDOM}.pem',
        '/logs/app_error_{RANDOM}.log',
        '/.git/config_{RANDOM}'
    ];

    private static function imul(int $a, int $b): int
    {
        $ah = ($a >> 16) & 0xffff;
        $al = $a & 0xffff;
        $bh = ($b >> 16) & 0xffff;
        $bl = $b & 0xffff;
        $lo = $al * $bl;
        $hi = (($lo >> 16) + ($al * $bh) + ($ah * $bl)) & 0xffff;
        return (($hi << 16) | ($lo & 0xffff)) | 0;
    }

    private static function generateBlock(string $seed, int $blockIndex, int $blockSize = 1024): string
    {
        $block = str_repeat("\x00", $blockSize);
        $h = FingerprintBuilder::cyrb53($seed . ":" . $blockIndex);
        
        $h_int = (int)bcmod($h, '4294967296');
        for ($i = 0; $i < $blockSize; $i++) {
            $h_int = self::imul($h_int ^ $i, 1597334677);
            $block[$i] = chr($h_int & 0xff);
        }
        return $block;
    }

    public static function registerCooperativeNode(string $clientIp, string $nodeId, string $seed): void
    {
        $subnet = RequestUtils::getIpSubnet($clientIp);
        if ($subnet === null) {
            return;
        }
        $store = StoreManager::getStore();
        $key = "coop-pospace:subnet:{$subnet}";
        $nodes = $store->get($key) ?? [];
        
        $now = time();
        // Nettoyage des nœuds expirés (vieux de plus de 2 minutes)
        $nodes = array_filter($nodes, fn($n) => ($now - $n['timestamp']) < 120);
        
        $nodes[$nodeId] = [
            'nodeId' => $nodeId,
            'seed' => $seed,
            'timestamp' => $now
        ];
        
        $store->set($key, $nodes, 120);
    }

    public static function findPeerInSubnet(string $clientIp, string $excludeNodeId): ?array
    {
        $subnet = RequestUtils::getIpSubnet($clientIp);
        if ($subnet === null) {
            return null;
        }
        $store = StoreManager::getStore();
        $key = "coop-pospace:subnet:{$subnet}";
        $nodes = $store->get($key) ?? [];
        
        $now = time();
        $activePeers = [];
        foreach ($nodes as $id => $node) {
            if ($id !== $excludeNodeId && ($now - $node['timestamp']) < 120) {
                $activePeers[] = $node;
            }
        }
        
        if (empty($activePeers)) {
            return null;
        }
        
        return $activePeers[array_rand($activePeers)];
    }

    public static function handleCooperativeRequest(array $params, string $clientIp = '127.0.0.1', array $config = []): ?array
    {
        $op = $params['coop_op'] ?? null;
        if (!$op) {
            return null;
        }

        $store = StoreManager::getStore();


        if ($op === 'share_threat_intel') {
            $peers = $config['federatedPeers'] ?? [];
            if (!empty($peers)) {
                $allowedHosts = array_map(function ($url) {
                    $host = parse_url($url, PHP_URL_HOST);
                    return !empty($host) ? $host : $url;
                }, $peers);

                if (!in_array($clientIp, $allowedHosts, true)) {
                    return ['error' => 'Unauthorized federation sender IP'];
                }
            }
            $zkpY = $params['zkpY'] ?? '';
            $headers = function_exists('getallheaders') ? array_change_key_case(getallheaders(), CASE_LOWER) : [];
            $sigEd25519 = $params['signature_ed25519'] ?? $headers['x-federation-signature-ed25519'] ?? $_SERVER['HTTP_X_FEDERATION_SIGNATURE_ED25519'] ?? '';
            $sigHmac = $params['signature'] ?? $headers['x-federation-signature'] ?? $_SERVER['HTTP_X_FEDERATION_SIGNATURE'] ?? '';
            $timestamp = (int)($params['timestamp'] ?? $headers['x-federation-timestamp'] ?? $_SERVER['HTTP_X_FEDERATION_TIMESTAMP'] ?? 0);

            if (empty($zkpY) || empty($timestamp)) {
                return ['error' => 'Missing threat intel parameters'];
            }

            // Time window check (5 minutes anti-replay)
            $now = (int)(microtime(true) * 1000);
            if (abs($now - $timestamp) > 300000) {
                return ['error' => 'Message expired or clock skew too high'];
            }

            $msg = "{$timestamp}:{$zkpY}";

            if (!empty($sigEd25519)) {
                $publicKey = $config['ed25519_public_key'] ?? $_ENV['ED25519_PUBLIC_KEY'] ?? getenv('ED25519_PUBLIC_KEY');
                if (!$publicKey) {
                    return ['error' => 'Missing public key for asymmetric verification'];
                }
                try {
                    $cleanKey = str_replace('\n', "\n", $publicKey);
                    $pubKeyObj = openssl_pkey_get_public($cleanKey);
                    if (!$pubKeyObj || openssl_verify($msg, hex2bin($sigEd25519), $pubKeyObj, null) !== 1) {
                        return ['error' => 'Invalid asymmetric federation signature'];
                    }
                } catch (\Throwable $e) {
                    return ['error' => 'Asymmetric signature verification failed'];
                }
            } elseif (!empty($sigHmac)) {
                $secret = $params['federationSecret'] ?? $config['federationSecret'] ?? self::getPowSecret();
                $expectedSig = hash_hmac('sha256', $msg, $secret);
                if (!hash_equals($expectedSig, $sigHmac)) {
                    return ['error' => 'Invalid federation signature'];
                }
            } else {
                return ['error' => 'Missing signature'];
            }

            $peersKey = "fed-peers:{$zkpY}";
            $reportedPeers = $store->get($peersKey) ?: [];
            if (!is_array($reportedPeers)) {
                $reportedPeers = [];
            }
            if (!in_array($clientIp, $reportedPeers, true)) {
                $reportedPeers[] = $clientIp;
                $store->set($peersKey, $reportedPeers, 86400 * 30);
            }

            $threshold = $config['federationConsensusThreshold'] ?? 3;
            if (count($reportedPeers) >= $threshold) {
                $store->set("banned-zkp-y:{$zkpY}", true, 86400 * 30);
                return ['status' => 'synchronized', 'banned' => true];
            }
            return ['status' => 'synchronized', 'banned' => false, 'reportsCount' => count($reportedPeers)];
        }

        $nodeId = $params['node_id'] ?? '';
        if (empty($nodeId)) {
            return ['error' => 'Missing node_id'];
        }

        // --- VÉRIFICATION DE LA SIGNATURE COOPÉRATIVE ---
        $challengeContext = $store->get("secret:{$nodeId}");
        if (!$challengeContext || empty($challengeContext['clientSecret'])) {
            return ['error' => 'Invalid or expired node_id'];
        }

        $clientSecret = $challengeContext['clientSecret'];
        $coopSig = $params['coop_sig'] ?? '';

        $expectedMsg = '';
        switch ($op) {
            case 'register':
                $expectedMsg = "{$clientSecret}:register:{$nodeId}:" . ($params['seed'] ?? '');
                break;
            case 'find_peer':
                $expectedMsg = "{$clientSecret}:find_peer:{$nodeId}";
                break;
            case 'webrtc_signal':
                $expectedMsg = "{$clientSecret}:webrtc_signal:{$nodeId}:" . ($params['target_peer_id'] ?? '') . ":" . ($params['signal_type'] ?? '') . ":" . ($params['signal_data'] ?? '');
                break;
            case 'poll_signals':
                $expectedMsg = "{$clientSecret}:poll_signals:{$nodeId}";
                break;
            case 'request_peer_block':
                $expectedMsg = "{$clientSecret}:request_peer_block:{$nodeId}:" . ($params['peer_id'] ?? '') . ":" . ($params['block_idx'] ?? '0') . ":" . ($params['req_id'] ?? '');
                break;
            case 'poll_requests':
                $expectedMsg = "{$clientSecret}:poll_requests:{$nodeId}";
                break;
            case 'respond_block':
                $expectedMsg = "{$clientSecret}:respond_block:{$nodeId}:" . ($params['requester_id'] ?? '') . ":" . ($params['req_id'] ?? '') . ":" . ($params['block_data'] ?? '');
                break;
            case 'poll_response':
                $expectedMsg = "{$clientSecret}:poll_response:{$nodeId}:" . ($params['req_id'] ?? '');
                break;
            default:
                return ['error' => 'Invalid cooperative operation'];
        }

        $expectedSig = hash('sha256', $expectedMsg);
        if (!hash_equals($expectedSig, $coopSig)) {
            return ['error' => 'Invalid cooperative signature'];
        }
        // --- FIN DE LA VÉRIFICATION ---

        switch ($op) {
            case 'register':
                $clientIp = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
                $seed = $params['seed'] ?? '';
                self::registerCooperativeNode($clientIp, $nodeId, $seed);
                return ['status' => 'registered'];

            case 'find_peer':
                $peer = self::findPeerInSubnet($clientIp, $nodeId);
                if ($peer !== null) {
                    return ['status' => 'peer_found', 'peer_id' => $peer['nodeId'], 'seed' => $peer['seed']];
                }
                return ['status' => 'no_peers'];

            case 'webrtc_signal':
                $targetPeerId = $params['target_peer_id'] ?? '';
                $signalType = $params['signal_type'] ?? '';
                $signalData = $params['signal_data'] ?? '';
                if (empty($targetPeerId) || empty($signalType) || empty($signalData)) {
                    return ['error' => 'Invalid parameters'];
                }
                $signalQueueKey = "coop-webrtc:signals:{$targetPeerId}";
                $signals = $store->get($signalQueueKey) ?? [];
                $signals[] = [
                    'from_peer_id' => $nodeId,
                    'signal_type' => $signalType,
                    'signal_data' => $signalData
                ];
                $store->set($signalQueueKey, $signals, 30);
                return ['status' => 'signal_queued'];

            case 'poll_signals':
                $pollSignalKey = "coop-webrtc:signals:{$nodeId}";
                $signals = $store->get($pollSignalKey) ?? [];
                if (!empty($signals)) {
                    $store->delete($pollSignalKey);
                }
                return ['status' => 'ok', 'signals' => $signals];

            case 'request_peer_block':
                $peerId = $params['peer_id'] ?? '';
                $blockIdx = (int)($params['block_idx'] ?? 0);
                $requestId = $params['req_id'] ?? '';
                if (empty($peerId) || empty($requestId)) {
                    return ['error' => 'Invalid parameters'];
                }
                
                $queueKey = "coop-mailbox:queue:{$peerId}";
                $requests = $store->get($queueKey) ?? [];
                $requests[] = [
                    'req_id' => $requestId,
                    'requester_id' => $nodeId,
                    'block_idx' => $blockIdx
                ];
                $store->set($queueKey, $requests, 30);
                return ['status' => 'queued'];

            case 'poll_requests':
                $queueKey = "coop-mailbox:queue:{$nodeId}";
                $requests = $store->get($queueKey) ?? [];
                $store->delete($queueKey);
                return ['requests' => $requests];

            case 'respond_block':
                $requesterId = $params['requester_id'] ?? '';
                $requestId = $params['req_id'] ?? '';
                $blockData = $params['block_data'] ?? '';
                if (empty($requesterId) || empty($requestId)) {
                    return ['error' => 'Invalid parameters'];
                }
                
                $responseKey = "coop-mailbox:res:{$requesterId}:{$requestId}";
                $store->set($responseKey, ['block_data' => $blockData], 30);
                return ['status' => 'delivered'];

            case 'poll_response':
                $requestId = $params['req_id'] ?? '';
                $responseKey = "coop-mailbox:res:{$nodeId}:{$requestId}";
                $data = $store->get($responseKey);
                if ($data) {
                    $store->delete($responseKey);
                    return ['status' => 'ready', 'block_data' => $data['block_data']];
                }
                return ['status' => 'pending'];
        }
        return null;
    }

    public static function generateSpaceChallenge(string $clientIp, string $nonce, float $suspicionFactor, string $originalUrl, array $securityConfig): array
    {
        $pospaceConfig = $securityConfig['pospace'] ?? [];
        $sizeMb = $pospaceConfig['sizeMb'] ?? 100;
        $numQueries = $pospaceConfig['numQueries'] ?? 10;

        $queries = [];
        $maxBlocks = $sizeMb * 1024;
        while (count($queries) < $numQueries) {
            $idx = random_int(0, $maxBlocks - 1);
            if (!in_array($idx, $queries, true)) {
                $queries[] = $idx;
            }
        }

        $challenge = [
            'type' => 'pospace',
            'nonce' => $nonce,
            'sizeMb' => $sizeMb,
            'queries' => $queries,
            'path' => $originalUrl
        ];

        // Tentative de couplage coopératif avec un nœud du même sous-réseau
        $peer = self::findPeerInSubnet($clientIp, $nonce);
        if ($peer !== null) {
            $challenge['peerId'] = $peer['nodeId'];
            $challenge['peerBlockIdx'] = random_int(0, $maxBlocks - 1);
            
            $store = StoreManager::getStore();
            $store->set("coop-assoc:{$nonce}", [
                'peerNodeId' => $peer['nodeId'],
                'peerSeed' => $peer['seed'],
                'peerBlockIdx' => $challenge['peerBlockIdx']
            ], 120);
        }

        return $challenge;
    }

    public static function verifySpacePoW(string $nonce, string $solution, array $queries, string $seed, string $clientSecret): bool
    {
        $combined = '';
        foreach ($queries as $idx) {
            $combined .= self::generateBlock($seed, (int)$idx);
        }
        
        // Vérification de la preuve coopérative
        $store = StoreManager::getStore();
        $assoc = $store->get("coop-assoc:{$nonce}");
        if ($assoc !== null) {
            $peerSeed = $assoc['peerSeed'] ?? null;
            $peerBlockIdx = $assoc['peerBlockIdx'] ?? null;
            if ($peerSeed !== null && $peerBlockIdx !== null) {
                $combined .= self::generateBlock($peerSeed, (int)$peerBlockIdx);
            }
            $store->delete("coop-assoc:{$nonce}");
        }

        $finalBlock = $combined . $nonce . ":" . $clientSecret;
        $hash = hash('sha256', $finalBlock);
        return hash_equals($hash, $solution);
    }

    public static function verifyZkpProof(string $yStr, string $tStr, string $sStr): bool
    {
        try {
            $p = BigInt::fromHex('fffffffffffffffffffffffffffffffffffffffffffffffffffffffefffffc2f'); // secp256k1 prime
            $g = new BigInt(2);

            $y = BigInt::fromHex($yStr);
            $t = BigInt::fromHex($tStr);
            $s = BigInt::fromHex($sStr);

            $cStr = (string)$g . (string)$y . (string)$t;
            $cHex = hash('sha256', $cStr);
            $c = BigInt::fromHex($cHex)->mod($p);

            $left = $g->modPow($s, $p);
            $y_c = $y->modPow($c, $p);
            $right = $t->mul($y_c)->mod($p);

            return $left->compareTo($right) === 0;
        } catch (\Throwable $e) {
            return false;
        }
    }

    /**
     * Récupère la clé secrète pour les PoW depuis les variables d'environnement.
     */
    public static function getPowSecret(): string
    {
        $secret = Env::get('POW_SECRET');
        $appEnv = Env::get('APP_ENV');
        if (!$secret && $appEnv === 'production') {
            throw new \RuntimeException('POW_SECRET environment variable is not set. This is required for production.');
        }
        return $secret ?: "fallback-dev-secret-32-chars-minimum";
    }

    /**
     * Génère un ticket stateless chiffré et signé contenant le contexte d'autorisation.
     * @param array $payload
     * @return string
     */
    public static function generateStatelessTicket(array $payload): string
    {
        $ed25519Key = Env::get('ED25519_PRIVATE_KEY');
        if ($ed25519Key) {
            try {
                $serialized = json_encode($payload);
                $privateKey = openssl_pkey_get_private($ed25519Key);
                if ($privateKey && openssl_sign($serialized, $signature, $privateKey, null)) {
                    $base64UrlEncode = function ($input) {
                        return rtrim(strtr(base64_encode($input), '+/', '-_'), '=');
                    };
                    return 'ed25519.' . $base64UrlEncode($serialized) . '.' . $base64UrlEncode($signature);
                }
            } catch (\Throwable $e) {
                error_log("[ChallengeUtils] Ed25519 signing failed: " . $e->getMessage());
            }
        }

        $key = hash('sha256', self::getPowSecret(), true);
        $iv = random_bytes(16);
        $encrypted = openssl_encrypt(json_encode($payload), 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv);
        $signature = hash_hmac('sha256', $iv . $encrypted, $key, true);
        
        return rtrim(strtr(base64_encode($iv), '+/', '-_'), '=') . '.' .
               rtrim(strtr(base64_encode($encrypted), '+/', '-_'), '=') . '.' .
               rtrim(strtr(base64_encode($signature), '+/', '-_'), '=');
    }

    /**
     * Décode et valide un ticket stateless chiffré et signé.
     * @param string $ticket
     * @param string $secret
     * @return array|null
     */
    public static function parseStatelessTicket(string $ticket, string $secret = ''): ?array
    {
        try {
            if (str_starts_with($ticket, 'ed25519.')) {
                $parts = explode('.', $ticket);
                if (count($parts) !== 3) {
                    return null;
                }
                $base64UrlDecode = function ($input) {
                    return base64_decode(strtr($input, '-_', '+/'));
                };
                $payloadJson = $base64UrlDecode($parts[1]);
                $signature = $base64UrlDecode($parts[2]);
                
                $ed25519PubKey = Env::get('ED25519_PUBLIC_KEY');
                if (!$ed25519PubKey) {
                    error_log("[ChallengeUtils] ED25519_PUBLIC_KEY is not defined in environment.");
                    return null;
                }
                
                $publicKey = openssl_pkey_get_public($ed25519PubKey);
                if ($publicKey && openssl_verify($payloadJson, $signature, $publicKey, null) === 1) {
                    return json_decode($payloadJson, true);
                }
                return null;
            }
        } catch (\Throwable $e) {
            error_log("[ChallengeUtils] Ed25519 verification failed: " . $e->getMessage());
            return null;
        }

        $parts = explode('.', $ticket);
        if (count($parts) !== 3) {
            return null;
        }
        $base64UrlDecode = function ($input) {
            return base64_decode(strtr($input, '-_', '+/'));
        };
        $iv = $base64UrlDecode($parts[0]);
        $encrypted = $base64UrlDecode($parts[1]);
        $signature = $base64UrlDecode($parts[2]);
        if (!$iv || !$encrypted || !$signature || strlen($iv) !== 16) {
            return null;
        }
        $key = hash('sha256', !empty($secret) ? $secret : self::getPowSecret(), true);
        $expectedSignature = hash_hmac('sha256', $iv . $encrypted, $key, true);
        if (!hash_equals($expectedSignature, $signature)) {
            return null;
        }
        $decrypted = openssl_decrypt($encrypted, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv);
        return $decrypted !== false ? json_decode($decrypted, true) : null;
    }

    /**
     * Vérifie si un ticket de passage est valide (supporte les tickets opaques via store et le fallback legacy).
     * Supporte une clé secrète optionnelle passée en paramètre pour la compatibilité avec les tests.
     */
    public static function isTicketValid(
        ?string $ip,
        ?string $ticket,
        string $deviceId = '',
        string $deviceHash = '',
        bool $allowCrossNetworkRoaming = false,
        string $secret = '',
        string $zkpProof = ''
    ): bool {
        if (empty($ip) || empty($ticket)) {
            return false;
        }

        // Tentative de validation stateless d'abord
        $ticketData = self::parseStatelessTicket($ticket, $secret);
        if ($ticketData !== null) {
            $expiry = $ticketData['expiry'] ?? null;
            $originalIp = $ticketData['originalIp'] ?? null;
            $storedDeviceId = $ticketData['deviceId'] ?? '';
            $storedDeviceHash = $ticketData['deviceHash'] ?? '';

            if (!$expiry || (int)floor(microtime(true) * 1000) > (int)$expiry) {
                return false;
            }
                if ($storedDeviceHash && str_starts_with($storedDeviceHash, 'zkp:')) {
                    $expectedY = explode(':', $storedDeviceHash, 2)[1] ?? '';
                    if (!empty($zkpProof)) {
                        $zkpParts = explode(':', $zkpProof);
                        if (count($zkpParts) === 3 && $zkpParts[0] === $expectedY) {
                            if (self::verifyZkpProof($zkpParts[0], $zkpParts[1], $zkpParts[2])) {
                                return true;
                            }
                        }
                    }
                    return false;
                }
            if ($ip === $originalIp) {
                return true;
            }
            $currentSubnet = RequestUtils::getIpSubnet($ip);
            $originalSubnet = RequestUtils::getIpSubnet($originalIp);
            if ($currentSubnet !== null && $originalSubnet !== null && $currentSubnet === $originalSubnet) {
                return true;
            }
            if (!$allowCrossNetworkRoaming) {
                return false;
            }
            return !empty($deviceId) && $deviceId === $storedDeviceId && !empty($deviceHash) && $deviceHash === $storedDeviceHash;
        }

        $store = StoreManager::getStore();
        $ticketData = $store->get("ticket:{$ticket}");

        if ($ticketData !== null) {
            $expiry = $ticketData['expiry'] ?? null;
            $originalIp = $ticketData['originalIp'] ?? null;
            $storedDeviceId = $ticketData['deviceId'] ?? '';
            $storedDeviceHash = $ticketData['deviceHash'] ?? '';

            if (!$expiry || (int)floor(microtime(true) * 1000) > (int)$expiry) {
                $store->delete("ticket:{$ticket}");
                return false;
            }
                if ($storedDeviceHash && str_starts_with($storedDeviceHash, 'zkp:')) {
                    $expectedY = explode(':', $storedDeviceHash, 2)[1] ?? '';
                    if (!empty($zkpProof)) {
                        $zkpParts = explode(':', $zkpProof);
                        if (count($zkpParts) === 3 && $zkpParts[0] === $expectedY) {
                            if (self::verifyZkpProof($zkpParts[0], $zkpParts[1], $zkpParts[2])) {
                                return true;
                            }
                        }
                    }
                    return false;
                }

            if ($ip === $originalIp) {
                return true;
            }

            $currentSubnet = RequestUtils::getIpSubnet($ip);
            $originalSubnet = RequestUtils::getIpSubnet($originalIp);
            if ($currentSubnet !== null && $originalSubnet !== null && $currentSubnet === $originalSubnet) {
                return true;
            }

            if (!$allowCrossNetworkRoaming) {
                return false;
            }

            return !empty($deviceId) && $deviceId === $storedDeviceId && !empty($deviceHash) && $deviceHash === $storedDeviceHash;
        }

        // Fallback rétrocompatible pour les anciens tickets signés (sans état)
        if (!str_contains($ticket, ':')) {
            return false;
        }

        [$expiry, $sig] = explode(':', $ticket, 2);
        if (empty($expiry) || empty($sig) || (int)floor((float)$expiry) < (int)floor(microtime(true) * 1000)) {
            return false;
        }

        $expectedSig = hash_hmac('sha256', "{$ip}:{$expiry}", !empty($secret) ? $secret : self::getPowSecret());

        return hash_equals($expectedSig, $sig);
    }

    /**
     * Calcule la cible de difficulté pour un challenge CPU en fonction du facteur de suspicion.
     */
    public static function calculateCpuTarget(float $suspicionFactor, array $securityConfig): string
    {
        $cpuConfig = $securityConfig['cpu'] ?? [];
        $minDifficultyBits = (float)($cpuConfig['minDifficultyBits'] ?? 4);
        $maxDifficultyBits = (float)($cpuConfig['maxDifficultyBits'] ?? 22);

        $totalDifficultyBits = $minDifficultyBits + $suspicionFactor * ($maxDifficultyBits - $minDifficultyBits);

        if ($totalDifficultyBits <= 0) {
            // Cible maximale (challenge trivial)
            return (BigInt::pow(2, 256)->sub(new BigInt(1)))->toHex();
        }

        $shift = 256 - (int)floor($totalDifficultyBits);
        return (new BigInt(1))->shiftLeft($shift)->toHex();
    }

    /**
     * Crée le bloc de données de base pour le challenge CPU.
     */
    public static function createCpuChallengeBaseBlock(string $nonce, string $clientSecret, string $fingerprint, string $clientIp = '', string $tlsSessionId = ''): string
    {
        $parts = explode('|', $fingerprint);
        $filteredParts = array_filter($parts);
        sort($filteredParts);
        $sortedFingerprint = implode('|', $filteredParts);
        
        return "{$nonce}:{$clientSecret}:{$sortedFingerprint}:{$clientIp}:{$tlsSessionId}:";
    }

    /**
     * Vérifie une solution de PoW CPU et génère un ticket si elle est valide.
     * @return string|null Le ticket opaque en cas de succès, sinon null.
     */
    public static function verifyCpuTargetPoWAndGenerateTicket(
        string $clientIp,
        int $ticketTtl,
        string $nonce,
        string $solution,
        array $challengeContext,
        string $deviceId = '',
        string $deviceHash = ''
    ): ?string {
        // En mode HTTP (non sécurisé), aucun calcul SHA-256 n'est exigé
        if (!empty($challengeContext['isHttp'])) {
            error_log('[FP Server Verify] Mode HTTP détecté (insecure policy) : validation sans SHA-256 acceptée.');
            $expiry = (int)floor(microtime(true) * 1000) + $ticketTtl;
            return self::generateStatelessTicket([
                'expiry' => $expiry,
                'originalIp' => $clientIp,
                'deviceId' => $deviceId,
                'deviceHash' => $deviceHash
            ]);
        }

        $cpuTargetHex = $challengeContext['cpuTarget'] ?? null;
        $baseBlock = $challengeContext['baseBlock'] ?? null;

        if ($cpuTargetHex === null || $baseBlock === null) {
            error_log('[FP Server Verify] Invalid challenge context. Missing cpuTarget or baseBlock.');
            return null;
        }

        $finalBlock = $baseBlock . $solution;
        $hash = hash('sha256', $finalBlock);

        // Pad target to 64 hex characters to allow direct O(1) lexicographical comparison
        $paddedTarget = str_pad($cpuTargetHex, 64, '0', STR_PAD_LEFT);
        $isValid = strcmp($hash, $paddedTarget) < 0;

        if ($isValid) {
            error_log('[FP Server Verify] CPU PoW verification PASSED.');
            
            $expiry = (int)floor(microtime(true) * 1000) + $ticketTtl;
            $payload = [
                'expiry' => $expiry,
                'originalIp' => $clientIp,
                'deviceId' => $deviceId,
                'deviceHash' => $deviceHash
            ];
            return self::generateStatelessTicket($payload);
        }

        // Log details on failure
        error_log(sprintf(
            '[FP Server Verify] CPU PoW verification FAILED. Details: hashCalculated=0x%s, target=0x%s',
            $hash,
            $cpuTargetHex
        ));

        return null;
    }

    /**
     * Vérifie le limiteur de débit Token Bucket pour les demandes de challenge d'un sous-réseau.
     */
    public static function checkChallengeRateLimit(string $clientIp): bool
    {
        $subnet = RequestUtils::getIpSubnet($clientIp);
        if ($subnet === null) {
            return false;
        }

        $store = StoreManager::getStore();
        $key = "rate-limit:{$subnet}";
        $rateLimitData = $store->get($key) ?? [
            'tokens' => 5.0,
            'lastRefill' => microtime(true)
        ];

        $capacity = 5.0;
        $refillRate = 0.1; // 1 token toutes les 10 secondes
        $now = microtime(true);

        $elapsed = $now - $rateLimitData['lastRefill'];
        $tokens = min($capacity, $rateLimitData['tokens'] + $elapsed * $refillRate);

        if ($tokens < 1.0) {
            $store->set($key, [
                'tokens' => $tokens,
                'lastRefill' => $now
            ], 60);
            return false;
        }

        $store->set($key, [
            'tokens' => $tokens - 1.0,
            'lastRefill' => $now
        ], 60);

        return true;
    }

    /**
     * Vérifie une solution de PoW mémoire.
     */
    private static function getChallengedIndices(string $seed, int $solution, int $numBlocks, int $k = 4): array
    {
        $indices = [];
        $h = (int)bcmod(\Anonympins\Fingerprint\FingerprintBuilder::cyrb53($seed . ":" . $solution), '4294967296');
        for ($i = 0; $i < $k; $i++) {
            $h = self::gmp_imul($h ^ $i, 1597334677);
            $indices[] = abs($h) % $numBlocks;
        }
        return $indices;
    }

    private static function verifyMerkleProof(string $leafHash, int $index, array $proof, string $root): bool
    {
        $currentHash = $leafHash;
        $idx = $index;
        foreach ($proof as $sibling) {
            $combined = ($idx % 2 === 0) ? $currentHash . $sibling : $sibling . $currentHash;
            $currentHash = hash('sha256', hex2bin($combined));
            $idx = (int)floor($idx / 2);
        }
        return $currentHash === $root;
    }

    private static function verifyMemoryPoWLegacy(string $nonce, int $solution, int $difficulty, string $clientSecret): bool
    {
        $size = $difficulty * 1024 * 1024;
        $iterations = (int)floor($size / 16);
        $buffer = new \SplFixedArray((int)floor($size / 4));

        $seed = ":{$nonce}:{$clientSecret}";
        $h = 0;
        foreach (unpack('C*', $seed) as $byte) {
            $h += $byte;
        }

        for ($i = 0; $i < count($buffer); $i++) {
            $buffer[$i] = $h = self::gmp_imul($h ^ $i, 1597334677);
        }

        $finalHash = 0;
        $addr = count($buffer) > 0 ? $buffer[0] % count($buffer) : 0;
        for ($i = 0; $i < $iterations; $i++) {
            $addr = $buffer[$addr] % count($buffer);
            $finalHash ^= $addr;
        }

        return $finalHash === $solution;
    }

    public static function verifyMemoryPoW(
        string $nonce,
        string $solution,
        int $difficulty,
        string $clientSecret
    ): bool {
        if ($difficulty === 0) {
            return true;
        }
        $maxAllowedMemDifficulty = 128; // 128MB
        if ($difficulty > $maxAllowedMemDifficulty) {
            error_log("[Security] Memory PoW verification attempt with excessive difficulty: {$difficulty}MB. Denied.");
            return false;
        }

        if ($solution === '') {
            return false;
        }

        $data = json_decode($solution, true);
        if (json_last_error() !== JSON_ERROR_NONE || !isset($data['solution']) || !isset($data['merkleRoot']) || !isset($data['proofs'])) {
            if ($difficulty <= 4 && preg_match('/^\d+$/', $solution)) {
                return self::verifyMemoryPoWLegacy($nonce, (int)$solution, $difficulty, $clientSecret);
            }
            return false;
        }

        $sol = $data['solution'];
        $merkleRoot = $data['merkleRoot'];
        $proofs = $data['proofs'];

        $numBlocks = $difficulty * 256;
        $seed = ":{$nonce}:{$clientSecret}";

        $challengedIndices = self::getChallengedIndices($seed, (int)$sol, $numBlocks, 4);

        foreach ($challengedIndices as $b) {
            $proof = $proofs[$b] ?? $proofs[(string)$b] ?? null;
            if ($proof === null) return false;

            $blockBytes = '';
            $h = (int)bcmod(\Anonympins\Fingerprint\FingerprintBuilder::cyrb53($seed . ":" . $b), '4294967296');
            for ($i = 0; $i < 1024; $i++) {
                $h = self::gmp_imul($h ^ $i, 1597334677);
                $blockBytes .= pack('V', $h);
            }

            $expectedLeaf = hash('sha256', $blockBytes);

            if (!self::verifyMerkleProof($expectedLeaf, $b, $proof, $merkleRoot)) {
                return false;
            }
        }

        $blockCache = [];
        $getBlockElement = function (int $blockIdx, int $elementIdx) use (&$blockCache, $seed): int {
            if (!isset($blockCache[$blockIdx])) {
                $block = [];
                $h = (int)bcmod(\Anonympins\Fingerprint\FingerprintBuilder::cyrb53($seed . ":" . $blockIdx), '4294967296');
                for ($i = 0; $i < 1024; $i++) {
                    $h = self::gmp_imul($h ^ $i, 1597334677);
                    $block[$i] = $h;
                }
                $blockCache[$blockIdx] = $block;
            }
            return $blockCache[$blockIdx][$elementIdx];
        };

        $totalElements = $numBlocks * 1024;
        $addr = $totalElements > 0 ? $getBlockElement(0, 0) % $totalElements : 0;
        $addr = $addr & 0xffffffff;
        $expectedSolution = 0;
        $iterations = 1024;
        for ($i = 0; $i < $iterations; $i++) {
            $blockIdx = (int)floor($addr / 1024);
            $elementIdx = $addr % 1024;
            $addr = $getBlockElement($blockIdx, $elementIdx) % $totalElements;
            $addr = $addr & 0xffffffff;
            $expectedSolution ^= $addr;
        }

        return $expectedSolution === (int)$sol;
    }

    /**
     * Émule la multiplication 32-bit `Math.imul` de JavaScript.
     */
    private static function gmp_imul(int $a, int $b): int
    {
        $a_lo = $a & 0xffff;
        $a_hi = $a >> 16;
        $b_lo = $b & 0xffff;
        $b_hi = $b >> 16;
        return (($a_lo * $b_lo) + ((($a_hi * $b_lo + $a_lo * $b_hi) << 16) & 0xffffffff)) | 0;
    }

    /**
     * Génère une URL piège signée.
     * @param string $nonce Le nonce pour signer l'URL.
     * @return string L'URL piège.
     */
    public static function generateTrapUrl(string $nonce): string
    {
        $template = self::TRAP_URL_TEMPLATES[array_rand(self::TRAP_URL_TEMPLATES)];
        $randomPart = bin2hex(random_bytes(8));
        $path = str_replace('{RANDOM}', $randomPart, $template);

        $signature = substr(hash_hmac('sha256', $nonce . $path, self::getPowSecret()), 0, 16);
        return "{$path}?sig={$signature}";
    }

    /**
     * Vérifie si une URL donnée est une URL piège valide pour un nonce donné.
     * @param string $path Le chemin de la requête.
     * @param string $signature La signature provenant de la query string.
     * @param string $nonce Le nonce à vérifier.
     * @return bool
     */
    public static function verifyTrapUrl(string $path, string $signature, string $nonce): bool
    {
        if (empty($signature)) {
            return false;
        }
        $expectedSignature = substr(hash_hmac('sha256', $nonce . $path, self::getPowSecret()), 0, 16);
        // Utilise hash_equals pour une comparaison sécurisée contre les attaques temporelles.
        return hash_equals($expectedSignature, $signature);
    }

    /**
     * Charge le contenu du solveur JS pour l'injection inline.
     * @return string Le code JavaScript du solveur.
     */
    private static function getPowSolverCode(): string
    {
        $candidates = [
            __DIR__ . '/../../js/pow.solver.inline.js',
            __DIR__ . '/../assets/pow.solver.inline.js',
            __DIR__ . '/../js/pow.solver.inline.js',
            dirname(__DIR__, 2) . '/assets/pow.solver.inline.js',
            dirname(__DIR__, 2) . '/js/pow.solver.inline.js',
            dirname(__DIR__, 1) . '/assets/pow.solver.inline.js',
        ];
        if (defined('ABSPATH')) {
            $wpPluginSolver = ABSPATH . 'wp-content/plugins/fingerprint-wordpress/assets/pow.solver.inline.js';
            if (file_exists($wpPluginSolver)) {
                return file_get_contents($wpPluginSolver) ?: '';
            }
        }
        foreach ($candidates as $solverPath) {
            if (file_exists($solverPath)) {
                return file_get_contents($solverPath) ?: '';
            }
        }
        error_log("[ChallengeUtils] Erreur: Le fichier pow.solver.inline.js n'a pas été trouvé à l'emplacement attendu.");
        return '';
    }

    public static function generateSpaceChallengePage(array $challengeDetails, string $clientSecret, array $securityConfig): string
    {
        $nonce = $challengeDetails['nonce'];
        $sizeMb = $challengeDetails['sizeMb'];
        $queries = $challengeDetails['queries'];
        $path = $challengeDetails['path'];
        $peerId = $challengeDetails['peerId'] ?? '';
        $peerBlockIdx = $challengeDetails['peerBlockIdx'] ?? -1;
        $nodeId = $nonce;

        $solverCode = self::getPowSolverCode();
        $queriesJson = json_encode($queries);
        $coopTimeout = $securityConfig['pospace']['coopTimeout'] ?? 15;

        $safePath = json_encode($path, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_SLASHES);
        $safeNonce = json_encode($nonce, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_SLASHES);
        $safeClientSecret = json_encode($clientSecret, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_SLASHES);

        $challengeScript = <<<JS
          async function solve() {
            const nonce = {$safeNonce};
            const path = {$safePath};
            const clientSecret = {$safeClientSecret};
            const queries = {$queriesJson};
            const sizeMb = {$sizeMb};
            const nodeId = "{$nodeId}";
            const peerId = "{$peerId}";
            const peerBlockIdx = {$peerBlockIdx};
            const coopTimeout = {$coopTimeout};
            
            async function signCoop(op, nid, extra = "") {
              const msg = clientSecret + ":" + op + ":" + nid + (extra ? ":" + extra : "");
              const encoder = new TextEncoder();
              const data = encoder.encode(msg);
              const hashBuffer = await crypto.subtle.digest("SHA-256", data);
              return Array.from(new Uint8Array(hashBuffer)).map(b => b.toString(16).padStart(2, '0')).join('');
            }
            
            async function sendWebRtcSignal(targetId, type, data) {
              const sig = await signCoop("webrtc_signal", nodeId, targetId + ":" + type + ":" + data);
              await fetch(window.location.pathname + "?coop_op=webrtc_signal&node_id=" + nodeId + "&target_peer_id=" + targetId + "&signal_type=" + type + "&signal_data=" + encodeURIComponent(data) + "&coop_sig=" + sig);
            }

            document.getElementById('loader').innerText = '⚙️ Checking persistent local storage...';
            await new Promise(r => setTimeout(r, 10));
            
            try {
                await window.initializeSpace(nonce + ":" + clientSecret, sizeMb);
                
                if (peerId && peerBlockIdx !== -1) {
                    // Enregistrement coopératif
                    const sig = await signCoop("register", nodeId, nonce + ":" + clientSecret);
                    await fetch(window.location.pathname + "?coop_op=register&node_id=" + nodeId + "&seed=" + encodeURIComponent(nonce + ":" + clientSecret) + "&coop_sig=" + sig);
                }

                const peerConnections = {};
                
                // Écoute des signaux WebRTC et requêtes entrantes
                setInterval(async () => {
                    try {
                        const sigWebrtc = await signCoop("poll_signals", nodeId);
                        const resWebrtc = await fetch(window.location.pathname + "?coop_op=poll_signals&node_id=" + nodeId + "&coop_sig=" + sigWebrtc);
                        const dataWebrtc = await resWebrtc.json();
                        if (dataWebrtc.signals && dataWebrtc.signals.length > 0) {
                            for (const sig of dataWebrtc.signals) {
                                const fromId = sig.from_peer_id;
                                if (sig.signal_type === 'offer') {
                                    const pc = new RTCPeerConnection({ iceServers: [] });
                                    peerConnections[fromId] = pc;
                                    pc.onicecandidate = (e) => {
                                        if (e.candidate) sendWebRtcSignal(fromId, 'candidate', JSON.stringify(e.candidate));
                                    };
                                    pc.ondatachannel = (e) => {
                                        const dc = e.channel;
                                        dc.onmessage = async (evt) => {
                                            try {
                                                const req = JSON.parse(evt.data);
                                                if (req.type === 'get_block') {
                                                    document.getElementById('loader').innerText = '📤 Transfert direct P2P (WebRTC) du bloc vers le pair...';
                                                    const blockData = await window.readSpaceBlock(req.block_idx);
                                                    dc.send(JSON.stringify({ type: 'block_data', block_data: blockData }));
                                                }
                                            } catch (err) {}
                                        };
                                    };
                                    await pc.setRemoteDescription(new RTCSessionDescription(JSON.parse(sig.signal_data)));
                                    const answer = await pc.createAnswer();
                                    await pc.setLocalDescription(answer);
                                    await sendWebRtcSignal(fromId, 'answer', JSON.stringify(answer));
                                } else if (sig.signal_type === 'answer' && peerConnections[fromId]) {
                                    await peerConnections[fromId].setRemoteDescription(new RTCSessionDescription(JSON.parse(sig.signal_data)));
                                } else if (sig.signal_type === 'candidate' && peerConnections[fromId]) {
                                    await peerConnections[fromId].addIceCandidate(new RTCIceCandidate(JSON.parse(sig.signal_data)));
                                }
                            }
                        }
                    } catch (e) {}

                    try {
                        const sig = await signCoop("poll_requests", nodeId);
                        const res = await fetch(window.location.pathname + "?coop_op=poll_requests&node_id=" + nodeId + "&coop_sig=" + sig);
                        const data = await res.json();
                        if (data.requests && data.requests.length > 0) {
                            for (const req of data.requests) {
                                document.getElementById('loader').innerText = '📤 Transfert coopératif de bloc vers le pair...';
                                const blockData = await window.readSpaceBlock(req.block_idx);
                                const respSig = await signCoop("respond_block", nodeId, req.requester_id + ":" + req.req_id + ":" + blockData);
                                await fetch(window.location.pathname + "?coop_op=respond_block&node_id=" + nodeId + "&requester_id=" + req.requester_id + "&req_id=" + req.req_id + "&block_data=" + encodeURIComponent(blockData) + "&coop_sig=" + respSig);
                            }
                        }
                    } catch (e) {
                        console.error("Cooperative polling error", e);
                    }
                }, 800);
                
                let peerBlock = "";
                if (peerId && peerBlockIdx !== -1) {
                    document.getElementById('loader').innerText = '📥 Connexion WebRTC P2P directe au pair (' + peerId + ')...';

                    // 1. Échange direct P2P via WebRTC DataChannel (charge serveur = 0)
                    const webrtcTransferPromise = new Promise(async (resolve) => {
                        if (!window.RTCPeerConnection) return resolve(null);
                        try {
                            const pc = new RTCPeerConnection({ iceServers: [] });
                            peerConnections[peerId] = pc;
                            const dc = pc.createDataChannel("pospace-transfer");
                            pc.onicecandidate = (e) => {
                                if (e.candidate) sendWebRtcSignal(peerId, 'candidate', JSON.stringify(e.candidate));
                            };
                            dc.onopen = () => {
                                dc.send(JSON.stringify({ type: 'get_block', block_idx: peerBlockIdx }));
                            };
                            dc.onmessage = (e) => {
                                try {
                                    const msg = JSON.parse(e.data);
                                    if (msg.type === 'block_data' && msg.block_data) {
                                        resolve(msg.block_data);
                                    }
                                } catch (err) {}
                            };
                            const offer = await pc.createOffer();
                            await pc.setLocalDescription(offer);
                            await sendWebRtcSignal(peerId, 'offer', JSON.stringify(offer));
                        } catch (err) {
                            resolve(null);
                        }
                    });

                    const webrtcTimeoutPromise = new Promise((resolve) => setTimeout(() => resolve(null), 5000));
                    peerBlock = await Promise.race([webrtcTransferPromise, webrtcTimeoutPromise]);

                    if (peerBlock) {
                        document.getElementById('loader').innerText = '⚡ Bloc reçu en direct via WebRTC P2P sans transit serveur !';
                    } else {
                        // 2. Repli vers le relais HTTP si WebRTC échoue
                        document.getElementById('loader').innerText = '⚠️ WebRTC indisponible. Téléchargement via relais HTTP...';
                        const reqId = Math.random().toString(36).substring(2);
                        const reqSig = await signCoop("request_peer_block", nodeId, peerId + ":" + peerBlockIdx + ":" + reqId);
                        await fetch(window.location.pathname + "?coop_op=request_peer_block&node_id=" + nodeId + "&peer_id=" + peerId + "&block_idx=" + peerBlockIdx + "&req_id=" + reqId + "&coop_sig=" + reqSig);
                        
                        let attempts = 0;
                        while (attempts < coopTimeout) {
                            const pollSig = await signCoop("poll_response", nodeId, reqId);
                            const res = await fetch(window.location.pathname + "?coop_op=poll_response&node_id=" + nodeId + "&req_id=" + reqId + "&coop_sig=" + pollSig);
                            const data = await res.json();
                            if (data.status === 'ready') {
                                peerBlock = data.block_data;
                                break;
                            }
                            await new Promise(r => setTimeout(r, 1000));
                            attempts++;
                        }
                    }
                }
                
                document.getElementById('loader').innerText = '⚙️ Génération de la Preuve d\\'Espace...';
                const hash = await window.solveSpaceChallenge(nonce + ":" + clientSecret, queries, nonce, clientSecret, peerBlock);
                
                window.location.href = path + "?pow_type=pospace&pow_nonce=" + nonce + "&pow_solution_space=" + hash + (peerBlock ? "&pow_coop=1" : "");
            } catch(e) {
                document.getElementById('loader').innerText = "Error initializing local storage: " + e.message;
            }
          }
          solve();
JS;

        return "<html><head><title>Security Check</title></head><body style=\"font-family:sans-serif; text-align:center; padding-top:50px;\"><h1>Security Check (Level 2)</h1><p>We are verifying your storage allocation. This may take a few seconds on first load.</p><div id=\"loader\" style=\"margin:20px;\">⚙️ Initializing storage space...</div><script>{$solverCode}</script><script>{$challengeScript}</script></body></html>";
    }

    /**
     * Génère le contenu HTML pour un challenge combiné CPU + Mémoire.
     * @param array $cpuChallengeDetails
     * @param int $memoryDifficulty
     * @param string $clientSecret
     * @param array $securityConfig
     * @param array $trapUrls
     * @param string $originalFingerprint
     * @return string
     */
    public static function generateCombinedPoWChallengePage(
        array $cpuChallengeDetails,
        int $memoryDifficulty,
        string $clientSecret,
        array $securityConfig,
        array $trapUrls,
        string $originalFingerprint,
        string $clientIp = '',
        string $tlsSessionId = '',
        ?string $baseBlock = null,
        bool $isHttps = true
    ): string {
        $nonce = $cpuChallengeDetails['nonce'];
        $target = $cpuChallengeDetails['target']; // @phpstan-ignore-line
        $path = $cpuChallengeDetails['path'];
        $isHttp = !$isHttps;

        $solverCode = self::getPowSolverCode();
        if ($baseBlock === null || $baseBlock === '') {
            $baseBlock = self::createCpuChallengeBaseBlock($nonce, $clientSecret, $originalFingerprint, $clientIp, $tlsSessionId);
        }
        $baseBlockBytes = '[' . implode(',', array_values(unpack('C*', $baseBlock))) . ']';

        $trapTags = ['div', 'span', 'p', 'section'];
        $selectedTrapTag = $trapTags[array_rand($trapTags)];
        $layoutProps = [
            'position:absolute;left:-9999px;top:-9999px;transform:scale(0);pointer-events:none;',
            'position:fixed;left:-8888px;top:-8888px;opacity:0;pointer-events:none;width:0;height:0;overflow:hidden;',
            'display:none;visibility:hidden;pointer-events:none;'
        ];
        $selectedLayout = $layoutProps[array_rand($layoutProps)];

        $trapLinks = [];
        foreach ($trapUrls as $index => $url) {
            $nestingType = rand(0, 2);
            $innerHtml = ($nestingType === 1) ? "<b>&gt; " . ($index + 1) . "</b>" : (($nestingType === 2) ? "<i>&gt; " . ($index + 1) . "</i>" : "<span>&gt; " . ($index + 1) . "</span>");
            $trapLinks[] = "<a href=\"{$url}\" tabindex=\"-1\">{$innerHtml}</a>";
        }
        $trapLinksHtml = implode(' ', $trapLinks);
        $trapContainerHtml = "<{$selectedTrapTag} style=\"{$selectedLayout}\" aria-hidden=\"true\">{$trapLinksHtml}</{$selectedTrapTag}>";

        $safePath = json_encode($path, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_SLASHES);
        $safeNonce = json_encode($nonce, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_SLASHES);
        $safeClientSecret = json_encode($clientSecret, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_SLASHES);
        $isHttpJs = $isHttp ? 'true' : 'false';

        $challengeScript = <<<JS
          async function solve() {
            const nonce = {$safeNonce};
            const path = {$safePath};
            const clientSecret = {$safeClientSecret};
            const isHttp = {$isHttpJs};
            const cpuTarget = BigInt("0x" + "{$target}");
            const memDifficulty = {$memoryDifficulty};
            const baseBlock = new Uint8Array({$baseBlockBytes});

            if (isHttp) {
                document.getElementById('loader').innerText = '⚠️ Connexion HTTP non sécurisée : validation simplifiée en cours...';
                await new Promise(r => setTimeout(r, 150));
                const finalUrl = path + "?pow_type=cpu_mem&pow_nonce=" + nonce + "&pow_solution_cpu=http_simulacre_ack&pow_solution_mem=0";
                window.location.href = finalUrl;
                return;
            }

            document.getElementById('loader').innerText = '⚙️ Performing CPU security calculation...';
            const cpuSolution = await window.solveCpuChallengeInline(baseBlock, cpuTarget, (progress) => {});

            if (memDifficulty > 0) {
                document.getElementById('loader').innerText = '⚙️ Performing memory allocation and calculation... (' + memDifficulty + ' MB)';
                await new Promise(r => setTimeout(r, 10));
            }
            let memSolution = 0;
            try {
                const memSeed = ":" + nonce + ":" + clientSecret;
                memSolution = await window.solveMemoryChallenge(memSeed, memDifficulty);
            } catch(e) {
                document.getElementById('loader').innerText = "Error: Insufficient memory. Please refresh.";
                return;
            }

        const finalUrl = path + "?pow_type=cpu_mem&pow_nonce=" + nonce + "&pow_solution_cpu=" + cpuSolution + "&pow_solution_mem=" + encodeURIComponent(JSON.stringify(memSolution));
            window.location.href = finalUrl;
          }
          solve();
JS;

        $htmlTemplate = '<html><head><title>Advanced Security Check</title></head><body style="font-family:sans-serif; text-align:center; padding-top:50px;"><h1>Enhanced Verification... (Level 2)</h1><p>Your activity requires an additional security check. This may take a few moments.</p><div id="loader" style="margin:20px;">⚙️ Initializing combined verification...</div><script><!-- FINGERPRINT_SOLVER_SCRIPT --></script><script><!-- FINGERPRINT_CHALLENGE_SCRIPT --></script><!-- FINGERPRINT_TRAPS --></body></html>';
        $customTemplatePath = $securityConfig['challengePagePath'] ?? null;

        if ($customTemplatePath && file_exists($customTemplatePath)) {
            $htmlTemplate = file_get_contents($customTemplatePath) ?: $htmlTemplate;
        }

        return str_replace(
            ['<!-- FINGERPRINT_SOLVER_SCRIPT -->', '<!-- FINGERPRINT_CHALLENGE_SCRIPT -->', '<!-- FINGERPRINT_TRAPS -->'],
            [$solverCode, $challengeScript, $trapContainerHtml],
            $htmlTemplate
        );
    }
}
<?php

declare(strict_types=1);

namespace Anonympins\Fingerprint;

use Anonympins\Fingerprint\Optimization\FunctionRegistry;
use Anonympins\Fingerprint\Optimization\ProblemInitializers;
use Anonympins\Fingerprint\Store\IStore;

class ProblemManager
{
    private static ?ProblemManager $instance = null;
    private string $configPath;
    private IStore $store;
    /** @var array<int, array<string, mixed>> */
    private array $problems = [];
    private int $currentProblemIndex = 0;
    private bool $initialized = false;
    
    /**
     * Le constructeur est privé pour forcer l'utilisation du singleton.
     */
    private function __construct(string $configPath, IStore $store)
    {
        $this->configPath = $configPath;
        $this->store = $store;
        $this->loadProblems();
    }

    /**
     * Obtient l'instance singleton du ProblemManager.
     * Doit être initialisé une fois avec `init`.
     */
    public static function getInstance(?string $configPath = null, ?IStore $store = null): self
    {
        if (self::$instance === null) {
            if ($configPath === null) {
                $defaultPath = dirname(__DIR__, 2) . '/config/problems.config.json';
                $configPath = file_exists($defaultPath) ? $defaultPath : null;
            }
            // Si on essaie d'obtenir l'instance sans l'initialiser d'abord, c'est une erreur.
            if ($configPath === null || $store === null) {
                throw new \RuntimeException("ProblemManager must be initialized with configPath and store.");
            }
            self::$instance = new self($configPath, $store);
        }
        return self::$instance;
    }

    public static function isInitialized(): bool
    {
        return self::$instance !== null && self::$instance->initialized;
    }
    /**
     * Charge et parse les problèmes depuis le fichier de configuration.
     */

    private function loadProblems(): void
    {
        if (!file_exists($this->configPath)) {
            error_log("[ProblemManager] Problem config file not found: {$this->configPath}");
            return;
        }
        $data = file_get_contents($this->configPath);
        if ($data === false) {
            error_log("[ProblemManager] Failed to read problem config file: {$this->configPath}");
            return;
        }
        $problemsFromFile = json_decode($data, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            error_log("[ProblemManager] Failed to parse problem config JSON: " . json_last_error_msg());
            return;
        }

        foreach ($problemsFromFile as $problem) {
            $storeKey = "problem-state:{$problem['id']}";
            $storedState = $this->store->get($storeKey);

            if ($storedState === null) {
                $storedState = $problem['state'] ?? [];
                $this->store->set($storeKey, $storedState); // Persist initial state
            }
            $problem['state'] = $storedState;

            // Résolution dynamique des fonctions et des données
            if (isset($problem['workUnit']['scoreFunction'])) {
                $problem['workUnit']['scoreFunction'] = FunctionRegistry::get($problem['workUnit']['scoreFunction']);
                if ($problem['workUnit']['scoreFunction'] === null) {
                    // @codeCoverageIgnoreStart
                    error_log("[ProblemManager] Warning: scoreFunction '{$problem['workUnit']['scoreFunction']}' not found in registry for problem '{$problem['id']}'.");
                    // @codeCoverageIgnoreEnd
                }
            }

            if (isset($problem['payload']) && is_array($problem['payload'])) {
                foreach ($problem['payload'] as $key => &$value) {
                    if (is_array($value) && isset($value['$init'])) {
                        $initializer = ProblemInitializers::get($value['$init']);
                        if ($initializer) {
                            $value = $initializer($value['params'] ?? []);
                        }
                    }
                }
            }
            $this->problems[] = $problem;
        }
        $this->initialized = true; // Marquer comme initialisé seulement après un chargement réussi
    }

    public function dispatchWork(float $suspicionFactor): ?array
    {
        if (empty($this->problems)) {
            return null;
        }

        $problem = $this->problems[$this->currentProblemIndex];
        $this->currentProblemIndex = ($this->currentProblemIndex + 1) % count($this->problems);

        $task = ['type' => $problem['workUnit']['type']];
        $scalingFactor = $problem['workUnit']['scalingFactor'] ?? null;

        switch ($problem['workUnit']['type']) {
            case 'simulated_annealing_iterations':
                $baseIterations = $problem['workUnit']['baseIterations'] ?? 15000;
                $task['iterations'] = $scalingFactor
                    ? (int)floor($baseIterations * pow($scalingFactor, $suspicionFactor))
                    : (int)floor($baseIterations * (0.5 + $suspicionFactor));
                if (isset($problem['payload'])) {
                    $task['payload'] = $problem['payload'];
                }
                // Ensure payload is always an array to prevent errors when accessing it.
                $task['payload'] = $task['payload'] ?? [];
                $task['initialSolution'] = $problem['state']['bestSolution'] ?? null;
                break;
                
            case 'genetic_algorithm_generations':
                $baseGenerations = max(50, $problem['workUnit']['baseGenerations'] ?? 0);
                $task['generations'] = $scalingFactor
                    ? (int)floor($baseGenerations * pow($scalingFactor, $suspicionFactor))
                    : (int)floor($baseGenerations * (0.5 + $suspicionFactor));
                if (isset($problem['payload'])) {
                    $task['payload'] = $problem['payload'];
                }
                $task['payload'] = $task['payload'] ?? [];
                $task['initialPopulation'] = $problem['state']['population'] ?? null;
                break;

            case 'run_multiple_parallel':
                $task['solverName'] = $problem['workUnit']['solverName'] ?? null;
                $task['numCycles'] = $problem['workUnit']['numCycles'] ?? null;
                $task['baseSolverArgs'] = $problem['payload']['baseSolverArgs'] ?? null;
                $task['workerDataGenerator'] = $problem['payload']['workerDataGenerator'] ?? null;
                $task['logProgress'] = $problem['payload']['logProgress'] ?? false;
                $task['concurrency'] = $problem['payload']['concurrency'] ?? null;
                break;
                
            case 'multi_objective_genetic_algorithm':
                $baseGenerationsMulti = max(30, $problem['workUnit']['baseGenerations'] ?? 0);
                $task['generations'] = $scalingFactor
                    ? (int)floor($baseGenerationsMulti * pow($scalingFactor, $suspicionFactor))
                    : (int)floor($baseGenerationsMulti * (0.5 + $suspicionFactor));
                if (isset($problem['payload'])) {
                    $task['payload'] = $problem['payload'];
                }
                $task['initialFront'] = $problem['state']['paretoFront'] ?? null;
                $task['solverName'] = $problem['workUnit']['solverName'];
                break;
            default:
                error_log("[ProblemManager] Unknown useful work type: {$problem['workUnit']['type']}");
                return null;
        }

        return ['problemId' => $problem['id'], 'task' => $task];
    }

    /**
     * Intègre la solution d'un client dans l'état du problème.
     *
     * @param string $problemId L'ID du problème.
     * @param array $solutionData La solution renvoyée par le client.
     */
    public function integrateSolution(string $problemId, array $solutionData): void
    {
        $problemIndex = array_search($problemId, array_column($this->problems, 'id'));
        if ($problemIndex === false) {
            return;
        }
        $problem = &$this->problems[$problemIndex]; // Use reference to modify in place

        $stateChanged = false;

        $storeKey = "problem-state:{$problem['id']}";

        // La logique d'intégration dépend du type de problème.
        switch ($problem['workUnit']['type']) {
            case 'simulated_annealing_iterations':
                if (isset($solutionData['solution']) && isset($solutionData['energy'])) {
                    $scoreFunction = $problem['workUnit']['scoreFunction'] ?? null;
                    if (!$scoreFunction) {
                        error_log("[ProblemManager] Aucune fonction de score définie pour {$problemId}.");
                        return;
                    }
                // DoS mitigation: validate solution size and structure
                if (is_array($solutionData['solution']) && count($solutionData['solution']) > 500) {
                    error_log("[ProblemManager] Solution array too large for {$problemId} verification.");
                    return;
                }
                $serializedSolution = json_encode($solutionData['solution']);
                if ($serializedSolution !== false && strlen($serializedSolution) > 65536) {
                    error_log("[ProblemManager] Solution payload size exceeds safe limit for {$problemId}.");
                    return;
                }
                    // 1. Ne JAMAIS faire confiance au score du client. Recalculer systématiquement.
                    $recalculatedEnergy = $scoreFunction($solutionData['solution'], $problem['payload'] ?? []);

                    $currentBest = (float)($problem['state']['bestEnergy'] ?? INF);

                    // 2. Comparer le score recalculé, pas celui du client.
                    if ($recalculatedEnergy < $currentBest) { // @phpstan-ignore-line
                        $problem['state']['bestSolution'] = $solutionData['solution'];
                        $problem['state']['bestEnergy'] = $recalculatedEnergy; // 3. Stocker le score vérifié.
                        $problem['state']['lastUpdate'] = (new \DateTime())->format(\DateTime::ATOM);
                        $stateChanged = true;
                        error_log("[ProblemManager] New best solution for {$problemId}: {$recalculatedEnergy}"); // @phpstan-ignore-line
                    }
                }
                break;
            case 'genetic_algorithm_generations':
                if (isset($solutionData['population']) && is_array($solutionData['population'])) {
                if (count($solutionData['population']) > 150) {
                    error_log("[ProblemManager] Population size exceeds safe limit for {$problemId}.");
                    return;
                }
                foreach ($solutionData['population'] as $ind) {
                    if (isset($ind['chromosome']) && is_array($ind['chromosome']) && count($ind['chromosome']) > 100) {
                        error_log("[ProblemManager] Chromosome size too large for {$problemId}.");
                        return;
                    }
                }

                    // VÉRIFICATION PAR ÉCHANTILLONNAGE (Parité avec JS)
                    $fitnessFunction = FunctionRegistry::get('portfolio.calculateMetrics');
                    if ($fitnessFunction) {
                        $sampleSize = min(5, count($solutionData['population']));
                        $sampleKeys = (array)array_rand($solutionData['population'], $sampleSize);
                        
                        foreach ($sampleKeys as $key) {
                            $individual = $solutionData['population'][$key];
                            if (isset($individual['chromosome'])) {
                                $recalculated = $fitnessFunction($individual['chromosome'], $problem['payload'] ?? []);
                                if (isset($individual['fitness']) && $individual['fitness'] !== -1) {
                                    if (abs($individual['fitness'] - $recalculated) > 1e-4) {
                                        error_log("[ProblemManager] Triche détectée pour {$problemId}! Fitness déclaré: {$individual['fitness']}, recalculé: {$recalculated}");
                                        return; // Rejeter en cas d'incohérence
                                    }
                                }
                                $solutionData['population'][$key]['fitness'] = $recalculated;
                            }
                        }
                    }

                    $problem['state']['population'] = $solutionData['population'];
                    $problem['state']['lastUpdate'] = (new \DateTime())->format(\DateTime::ATOM);
                    $stateChanged = true;
                }
                break;
            case 'multi_objective_genetic_algorithm':
                // Pour les algorithmes génétiques, on intègre le nouveau front de Pareto.
                if (isset($solutionData['paretoFront']) && is_array($solutionData['paretoFront'])) {
                    $stateChanged = $this->_integrateParetoFront($problem, $solutionData['paretoFront']);
                }
                break;
            default:
                error_log("[ProblemManager] Integration not implemented for useful work type: {$problem['workUnit']['type']}");
                break;
        }
        // Sauvegarder l'état mis à jour dans le store.
        if ($stateChanged) {
            $this->store->set($storeKey, $problem['state']);
        }
    }

    /**
     * Intègre un nouveau front de Pareto dans l'état du problème.
     *
     * @param array &$problem Le problème à mettre à jour (passé par référence).
     * @param array $newFront Le nouveau front de Pareto soumis par le client.
     */
    private function _integrateParetoFront(array &$problem, array $newFront): bool
    {
        // Logique de fusion et de tri non-dominé pour mettre à jour le front de Pareto.
        // Pour cet exemple, nous remplaçons simplement le front, mais une vraie implémentation
        // fusionnerait les deux fronts et recalculerait le meilleur.
        // On vérifie si le nouveau front est différent de l'actuel pour éviter des écritures inutiles.
        $currentFront = $problem['state']['paretoFront'] ?? [];
        if (!empty($newFront) && json_encode($newFront) !== json_encode($currentFront)) {
            $problem['state']['paretoFront'] = $newFront;
            $problem['state']['lastUpdate'] = (new \DateTime())->format(\DateTime::ATOM);
            error_log("[ProblemManager] New Pareto front for {$problem['id']} with " . count($newFront) . " solutions."); // @phpstan-ignore-line
            return true;
        }
        return false;
    }

    /**
     * S'assure qu'un problème a une solution initiale. Si non, en génère une.
     *
     * @param array &$problem Le problème à vérifier (passé par référence).
     */
    private function ensureInitialSolution(array &$problem): void
    {
        if (!empty($problem['state']['bestSolution'])) {
            return;
        }

        $scoreFunction = $problem['workUnit']['scoreFunction'] ?? null;
        $initialSolutionSourceKey = $problem['workUnit']['initialSolutionSource'] ?? '';
        $initialSolution = $problem['payload'][$initialSolutionSourceKey] ?? null;

        if ($scoreFunction && is_array($initialSolution)) {
            $score = $scoreFunction($initialSolution, $problem['payload'] ?? []);
            $problem['state']['bestSolution'] = $initialSolution;
            $problem['state']['bestEnergy'] = $score;
            $problem['state']['lastUpdate'] = (new \DateTime())->format(\DateTime::ATOM);
            $this->store->set("problem-state:{$problem['id']}", $problem['state']);
        }
    }

    /**
     * Formate l'état d'un problème pour l'export externe.
     */
    private function formatSolution(array $problem): ?array
    {
        if (!isset($problem['state'])) {
            return null;
        }

        if (($problem['workUnit']['type'] ?? '') === 'multi_objective_genetic_algorithm') {
            return [
                'id' => $problem['id'],
                'solution' => $problem['state']['paretoFront'] ?? [],
                'score' => count($problem['state']['paretoFront'] ?? []),
                'lastUpdate' => $problem['state']['lastUpdate'] ?? null,
            ];
        }

        return [
            'id' => $problem['id'],
            'solution' => $problem['state']['bestSolution'] ?? null,
            'score' => $problem['state']['bestEnergy'] ?? null,
            'lastUpdate' => $problem['state']['lastUpdate'] ?? null,
        ];
    }

    /**
     * Récupère la meilleure solution actuellement connue pour un ou plusieurs problèmes.
     *
     * @param string|null $problemId L'ID optionnel du problème à consulter.
     * @return array|null Un tableau associatif ou une liste de tableaux associatifs.
     */
    public function getBestSolutions(?string $problemId = null): ?array
    {
        $problemsToProcess = [];
        foreach ($this->problems as &$p) {
            if ($problemId === null || $p['id'] === $problemId) {
                if (($p['workUnit']['type'] ?? '') !== 'multi_objective_genetic_algorithm') {
                    $this->ensureInitialSolution($p);
                }
                $problemsToProcess[] = $p;
            }
        }
        unset($p);

        if ($problemId !== null) {
            return !empty($problemsToProcess) ? $this->formatSolution($problemsToProcess[0]) : null;
        }

        $results = [];
        foreach ($this->problems as $p) {
            $formatted = $this->formatSolution($p);
            if ($formatted && $formatted['solution'] !== null) {
                $results[] = $formatted;
            }
        }
        return $results;
    }

    /**
     * Réinitialise l'instance singleton.
     * @internal Uniquement pour les tests.
     */
    public static function resetInstanceForTests(): void
    {
        self::$instance = null;
    }

    /**
     * Réinitialise l'instance singleton.
     * @internal Uniquement pour les tests.
     */
    public static function __internal_resetInstance(): void {
        self::$instance = null;
    }

    /**
     * @internal For testing purposes only.
     */
    public function getProblems(): array
    {
        return $this->problems;
    }
}